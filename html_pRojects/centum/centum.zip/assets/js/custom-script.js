// testimonials slider
var swiper = new Swiper(".testimonials .mySwiper", {
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
});
