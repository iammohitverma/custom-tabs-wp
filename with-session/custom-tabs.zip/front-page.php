<?php
get_header();
?>


<div class="page">
    <div class="container-">

        <?php
            the_content();
        ?>

    </div>
</div>


<?php
get_footer();
?>