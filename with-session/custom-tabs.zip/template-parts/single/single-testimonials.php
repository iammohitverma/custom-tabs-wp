<?php

the_content();

?>