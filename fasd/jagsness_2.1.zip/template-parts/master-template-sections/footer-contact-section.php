<section class="form_section pt_100 pb_100">
    <div class="container">
        <div class="inner">
            <div class="head">
                <h2 class="fs_48 form_title">Stay connected</h2>
                <p>Join our mailing list to hear more from the FASD Hub, including our monthly newsletters, webinar invitations, and new publications and resources.</p>
            </div>
            <div class="form_wrap">
                <form action="#" method="post" id="fasd_form">
                    <div class="row">
                        <div class="col-12 col-sm-12 col-md-6">
                            <div class="fname">
                                <label for="fname">First Name *</label>
                                <input class="required_field" type="text" name="fname">
                            </div>
                        </div>
                        <div class="col-12 col-sm-12 col-md-6">
                            <div class="lname">
                                <label for="fname">Last Name *</label>
                                <input class="required_field" type="text" name="lname">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="email">
                                <label for="fname">Email address *</label>
                                <input class="required_field email" type="text" name="email">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="submit_btn">
                                <input type="submit" name="lname" value="Subscribe">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="form_btm_content">
                <h3>Acknowledgement of Country</h3>
                <p>FASD Hub Australia acknowledges Aboriginal and Torres Strait Islander peoples as the Traditional Custodians of Country throughout Australia, and we recognise their connections to land, water and community. We pay our respect to their elders past and present, and extend that respect to all Aboriginal and Torres Strait Islander peoples.</p>
            </div>
        </div>
    </div>
</section>