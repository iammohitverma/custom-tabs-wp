jQuery(document).ready(function () {
    // toggle_menu for mobile
    jQuery(".fasd_header .toggle_menu").click(function () {
        jQuery(this).toggleClass("active");
        jQuery(".fasd_header .navigationWrap").slideToggle();
    })
    // submenu toggle for mobile
    jQuery(".fasd_header .subMenuAngle").click(function () {
        jQuery(this).toggleClass("active");
        jQuery(this).closest(".a-Wrap").next().slideToggle();
    })
    // search toggle for mobile
    jQuery(".fasd_header .search_toggle_mobile button").click(function () {
        jQuery(this).toggleClass("active");
        jQuery(".fasd_header .search_wrap").slideToggle();
    })
});
